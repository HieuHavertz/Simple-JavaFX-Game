package Game;

import java.io.*;
import javafx.animation.*;
import javafx.application.Application;
import javafx.beans.binding.*;
import javafx.geometry.*;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.*;
import javafx.scene.image.*;
import javafx.scene.input.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.scene.text.*;
import javafx.stage.Stage;
import javafx.util.Duration;

public class CatGame extends Application {
    static final double WIDTH = 1300, HEIGHT = 800;
    static int score;
    static Group playRoot, endRoot;
    static ImageView cat;
    static Scene scene;
    static Timeline mouseAppear;
    static Rectangle rectangle;
    static Text scoreText, endScoreText;
    static boolean running = true;

    @Override
    public void start(Stage stage) throws FileNotFoundException {
        playRoot = createPlayRoot();
        endRoot = createEndRoot();
        // Set scene for stage
        scene = new Scene(playRoot, Color.PEACHPUFF);
        //scene.setRoot(endRoot);
        scene.addEventFilter(KeyEvent.KEY_PRESSED, e -> {
            double y = cat.getY();
            if(e.getCode() == KeyCode.UP && y >= 15)
                cat.setY(y - 20);
            if(e.getCode() == KeyCode.DOWN && y <= scene.getHeight() - 100)
                cat.setY(y + 20);
            if(e.getCode() == KeyCode.A)
                scene.setRoot(endRoot);
        });
        stage.setTitle("Cat catches mice");
        stage.getIcons().add(new Image(new FileInputStream("src/main/java/image/Monkey.png")));
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    }

    public void createMouse(){
        try{
            Mouse mouse = new Mouse();
            playRoot.getChildren().add(mouse);
            
            // Check if cat touched mouse
            BooleanBinding catched = Bindings.createBooleanBinding(
                () -> cat.getBoundsInParent().intersects(mouse.getImageView().getBoundsInParent()),
                cat.boundsInParentProperty(), mouse.getImageView().boundsInParentProperty());
            
            catched.addListener((obs, wasCatched, isNowCatched) -> {
            if(isNowCatched){
                mouse.stopMouse();
                playRoot.getChildren().remove(mouse);
                scoreText.setText("SCORE: " + (++score));
                if(score % 5 == 0){
                    mouseAppear.setRate(mouseAppear.getRate() + 0.2);
                    mouse.increaseSpeed();
                }
            }});
        }catch(FileNotFoundException e){
        }
    }
    
    private Group createPlayRoot() throws FileNotFoundException{
        scoreText = new Text(200, 50, "SCORE: " + score);
        scoreText.setFont(Font.font("Ink free", 50));
        scoreText.setFill(Color.BROWN);
        
        cat = new ImageView(new Image(new FileInputStream("src/main/java/image/neko.png")));
        cat.setX(1000);     cat.setY(300);
        
        // Create mouse every 1.5s
        mouseAppear = new Timeline(new KeyFrame(Duration.seconds(1.5), e -> createMouse()));
        mouseAppear.setCycleCount(Timeline.INDEFINITE);
        mouseAppear.play();
        
        rectangle = new Rectangle(1290, 0, 10, 800);
        rectangle.setFill(Color.DARKGOLDENROD);
        
        Canvas canvas = new Canvas(WIDTH, HEIGHT);
        return new Group(canvas, cat, rectangle, scoreText);
    }
    
    private Group createEndRoot(){        
        Text gameOver = new Text("GAME OVER");
        endScoreText = new Text("SCORE: " + score);
        gameOver.setFont(Font.font("Curlz MT", FontWeight.BOLD, FontPosture.ITALIC, 100));
        gameOver.setFill(Color.CRIMSON);
        endScoreText.setFont(Font.font("Curlz MT", 60));
        endScoreText.setFill(Color.CRIMSON);
        
        VBox box = new VBox(gameOver, endScoreText);
        box.setAlignment(Pos.CENTER);
        BorderPane pane = new BorderPane();
        pane.setMinSize(WIDTH, HEIGHT);
        pane.setCenter(box);
        return new Group(pane);
    }
    
    public static void stopGame(){
        endScoreText.setText("SCORE: " + score);
        running = false;
        mouseAppear.stop();
        scene.setRoot(endRoot);
    }
    
    public static void main(String[] args) {
        launch(args);
    }
}