package Game;

import java.io.*;
import java.util.concurrent.ThreadLocalRandom;
import javafx.animation.*;
import javafx.scene.image.*;
import javafx.scene.layout.Pane;
import javafx.util.Duration;

public class Mouse extends Pane{
    private ImageView image = new ImageView(new Image(new FileInputStream("src/main/java/image/mouse.png")));
    private final Timeline animation;
    
    public Mouse() throws FileNotFoundException{
        double y = ThreadLocalRandom.current().nextDouble() * 700;
        getChildren().add(image);
        image.setY(y);
        animation = new Timeline(new KeyFrame(Duration.millis(20), e -> move()));
        animation.setCycleCount(Timeline.INDEFINITE);
        animation.play();
    }
    
    public void move(){
        image.setX(image.getX() + 10);
        if(image.getX() >= 1300)
            CatGame.stopGame();
    }
    
    public boolean isEscape(){
        return image.getX() >= 1200;
    }
    
    public void stopMouse(){
        animation.stop();
    }
    
    public void increaseSpeed(){
        animation.setRate(animation.getRate() + 0.2);
    }

    public double getPointX(){
        return image.getX();
    }
    
    
    public ImageView getImageView(){
        return this.image;
    }
}
