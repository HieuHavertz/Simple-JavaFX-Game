module hieupc.javafx {
    requires javafx.controls;
    requires javafx.graphics;
    requires javafx.base;
    requires javafx.media;
    
    exports JavaFXchapter16;
    opens hieupc.javafx.App;
}
